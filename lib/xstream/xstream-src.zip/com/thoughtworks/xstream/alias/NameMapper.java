package com.thoughtworks.xstream.alias;

/**
 * @deprecated As of 1.2
 */
public interface NameMapper {
    /**
     * @deprecated As of 1.2
     */
    String fromXML(String elementName);

    /**
     * @deprecated As of 1.2
     */
    String toXML(String fieldName);
}
