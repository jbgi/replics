package org.jgroups.jmx.protocols;

/**
 * @author Bela Ban
 * @version $Id: UDPMBean.java,v 1.3 2005/08/17 07:32:29 belaban Exp $
 */
public interface UDPMBean extends TPMBean {
}
