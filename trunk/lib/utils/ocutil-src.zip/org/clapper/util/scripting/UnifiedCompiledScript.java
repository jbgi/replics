/*---------------------------------------------------------------------------*\
  $Id: UnifiedCompiledScript.java 6423 2006-09-13 02:14:50Z bmc $
\*---------------------------------------------------------------------------*/

package org.clapper.util.scripting;

/**
 * Representation of a compiled script. This interface has this awkward name
 * to avoid conflicts with the JSR 223 <tt>javax.script.CompiledScript</tt>
 * interface.
 *
 * @version <tt>$Revision: 6423 $</tt>
 */
public interface UnifiedCompiledScript
{
}
